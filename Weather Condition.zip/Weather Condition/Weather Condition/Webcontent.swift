//
//  Webcontent.swift
//  Weather Condition
//
//  Created by Tugce Tekerlekci on 7/7/16.
//  Copyright © 2016 Tugce Tekerlekci. All rights reserved.
//


import UIKit

var cityInfo = ""

class Webcontent: UIViewController {



    @IBOutlet var web: UIWebView!


    override func viewDidLoad() {
        super.viewDidLoad()
      
        
        let url = NSURL(string: "https://en.wikipedia.org/wiki/" + cityInfo)!
        print(cityInfo)
        
        
        
        web.loadRequest(NSURLRequest(URL: url))











    }







}




















